class Scenario(object):
    # Each Scenario is a list of instances of Sentence class
    def __init__(self, sentences=None):
        if sentences is None:
            self.sentences = []
        self.sentences = sentences

    def add_sentence(self, sentence):
        self.sentences.append(sentence)


class Sentence(object):
    # Each Sentence is a list of instances of Frame class
    def __init__(self, condition, text, frames, expectation=""):
        self.condition = condition
        self.text = text
        self.frames = frames
        self.expectation = expectation

    def set_condition(self, condition):
        self.condition = condition

    def set_frames(self, frames):
        self.frames = frames

    def add_frame(self, frame):
        self.frames.append(frame)

    def change_obj_mod(self, idx, obj_mod):
        self.frames[idx].obj_mod = obj_mod

class Frame(object):
    def __init__(self):
        pass


class ActiveVoice_Frame(Frame):
    def __init__(self, parsed_sentence):
        self.actor, self.actor_mod, self.action, self.obj, self.obj_mod = self.get_frame_keys(parsed_sentence)

    def get_frame_keys(self, parsed_sentence):
        # Actor
        actor = []
        actor_mod = []
        action = []
        obj = []
        obj_mod = []

        obj_mod_tags = ['amod', 'advmod', 'compound']
        for dependency in parsed_sentence['enhancedPlusPlusDependencies']:
            # Actor
            if dependency['dep'] == 'nsubj':
                actor.append(dependency['dependentGloss'])
            # Modifier of Actor
            elif dependency['dep'] == 'amod' and dependency['governorGloss'] == actor[0]:
                actor_mod.append(dependency['governorGloss'])
            # Action
            elif dependency['dep'] == 'ROOT':
                action.append(dependency['dependentGloss'])
            # Object
            elif dependency['dep'] == 'dobj':
                obj.append(dependency['dependentGloss'])
            # Object modifier
            elif dependency['dep'] in obj_mod_tags:
                obj_mod.append(dependency['dependentGloss'])
        return actor, actor_mod, action, obj, obj_mod


class Other_Frame(Frame):
    def __init__(self, parsed_sentence):
        self.actor, self.actor_mod, self.action, self.obj, self.obj_mod = self.get_frame_keys(parsed_sentence)

    def get_frame_keys(self, parsed_sentence):
        # Actor
        actor = []
        actor_mod = []
        action = []
        obj = []
        obj_mod = []

        obj_mod_tags = ['amod', 'advmod', 'compound']
        for dependency in parsed_sentence['enhancedPlusPlusDependencies']:
            # Actor
            if dependency['dep'] == 'nsubj':
                actor.append(dependency['dependentGloss'])
            # Modifier of Actor
            elif dependency['dep'] == 'amod':
                actor_mod.append(dependency['governorGloss'])
            # Action
            elif dependency['dep'] == 'ROOT':
                action.append(dependency['dependentGloss'])
            # Object
            elif dependency['dep'] == 'dobj':
                obj.append(dependency['dependentGloss'])
            # Object modifier
            elif dependency['dep'] in obj_mod_tags:
                obj_mod.append(dependency['dependentGloss'])
        return actor, actor_mod, action, obj, obj_mod
