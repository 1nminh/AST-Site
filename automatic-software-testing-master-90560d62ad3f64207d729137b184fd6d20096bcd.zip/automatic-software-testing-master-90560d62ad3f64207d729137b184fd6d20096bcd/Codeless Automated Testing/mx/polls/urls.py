from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('ajax/tier1/', views.tier2, name='tier2'),
    path('ajax/history', views.getTestCase, name='getTestCase'),
    path('ajax/runtest/',views.runtest, name='runtest'),
]
