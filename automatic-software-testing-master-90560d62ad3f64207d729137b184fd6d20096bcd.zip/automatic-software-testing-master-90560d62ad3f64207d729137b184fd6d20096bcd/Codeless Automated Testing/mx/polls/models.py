from django.db import models
from django import forms

# Create your models here.

class Item(models.Model):
    id = models.AutoField(primary_key=True)
    item_type = models.IntegerField(default=0)
    item_text = models.CharField(max_length=200)
    item_subName = models.CharField(max_length=200,null=True,blank=True)
    parent_id=models.ForeignKey('Item',on_delete='SET None',default=None,blank=True, null=True)
    locateItem_type=models.IntegerField(default=0)
     
    def __str__(self):
        return self.item_text

class ItemForm(forms.Form):
    
    def __init__(self, *args, **kwargs):
        super(ItemForm, self).__init__(*args, **kwargs)
        temp = Item.objects.filter(parent_id=None).all()
        self.fields['item'] = forms.ChoiceField(choices=[(i.id,i.item_text)for i in temp])
    
    
class LocateItem(models.Model):
    id = models.AutoField(primary_key=True)
    locate_type = models.IntegerField(default=0)
    locate_text = models.CharField(max_length=200)
    def __str__(self):
        return self.locate_text

class ItemSubNameForm(forms.Form):
    def __init__(self,subName, *args, **kwargs):
        super(ItemSubNameForm, self).__init__(*args, **kwargs)
        
        self.fields['subname'] = forms.CharField()
        self.fields['subname'].label = subName
class SuperItemSubNameForm(forms.Form):
    def __init__(self,subName, *args, **kwargs):
        super(SuperItemSubNameForm, self).__init__(*args, **kwargs)
        
        self.fields['supersubname'] = forms.CharField()
        self.fields['supersubname'].label = subName
class SubItemForm(forms.Form):
    def __init__(self,parentId,subName, *args, **kwargs):
        super(SubItemForm, self).__init__(*args, **kwargs)
        temp = Item.objects.filter(parent_id=parentId).all()

        self.fields['subitem'] = forms.ChoiceField(choices=[(i.id,i.item_text)for i in temp])
        self.fields['subitem'].label = subName
class SuperSubItemForm(forms.Form):
    def __init__(self,parentId,subName, *args, **kwargs):
        super(SuperSubItemForm, self).__init__(*args, **kwargs)
        temp = Item.objects.filter(parent_id=parentId).all()

        self.fields['supersubitem'] = forms.ChoiceField(choices=[(i.id,i.item_text)for i in temp])
        self.fields['supersubitem'].label = subName
class LocateItemForm(forms.Form):

    def __init__(self, type, *args, **kwargs):
        super(LocateItemForm,self).__init__(*args,**kwargs)
        self.fields['locateitem'] = forms.ChoiceField(choices=[(i.id, i.locate_text) for i in LocateItem.objects.filter(locate_type=type)])

class TestCase(models.Model):
    id = models.AutoField(primary_key=True)
    item_id = models.IntegerField(default=0)
    locateItem_id =  models.IntegerField(default=0)
    name = models.CharField(max_length=200,default="")
    subItem_id = models.IntegerField(default=0)
    item_subText = models.CharField(max_length=200,default="")
    locateItem_subText = models.CharField(max_length=200,default="")
    superItem_id = models.IntegerField(default=0)
    superItem_subText = models.CharField(max_length=200,default="")
    
