from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_protect

import os
import robot
import sqlite3

from .models import *
# Create your views here.
def index(request):
    

    context = {
        'item':ItemForm().as_p(),
         
    }
    

    #logFile = open('mylog.txt', 'w') 
    #test = robot.run(os.getcwd()+"/polls/robot/Demo.robot",test=['Google 1'],variable=['search:facebook','prediction:www.facebook.com'],stdout=logFile, outputdir="/home/hmcuong/Documents/mx/polls/robot", n="noncritical")
    #print(test)
    return render(request,"polls/index.html",context)


def getTestCase(request):
    allTestCase = list(TestCase.objects.all())
    listdata = []
    for testcase in allTestCase:
        
        item = Item.objects.filter(id=testcase.item_id).values('id','locateItem_type','item_type','item_subName').first()
        
        
        if(item['item_type']==1):
            
            listdata.append({"item_id":item['id'],'name' : testcase.name})

        if(item['item_type']==2):
            subNameForm = ItemSubNameForm(item['item_subName'])
            data ={                   
                'htmlCode' : subNameForm.as_p(),
                'type' : item['item_type']
            }
            listdata.append({
                "item_id":item['id'],
                'item_subText': testcase.item_subText,
                'data' : data,
                'name' : testcase.name
                })
        if(item['item_type']==3):
            subItemForm = SubItemForm(item['id'],item['item_subName'])                       
            subItem = Item.objects.filter(id=testcase.subItem_id).values('id','item_subName','item_type','locateItem_type').first()
            if(subItem['item_type']==1):
                data ={                   
                'htmlCode' : subItemForm.as_p(),
                'type' : item['item_type'],
                'subType' :subItem['item_type']
                }
                listdata.append({
                "item_id":item['id'],
                'subItem_id': testcase.subItem_id,
                'data' : data,'name' : testcase.name
                })
            if(subItem['item_type']==2):
                subNameForm = ItemSubNameForm(subItem['item_subName'])
                data ={                   
                'htmlCode' : subItemForm.as_p(),
                'type' : item['item_type'],
                'htmlNameCode' : subNameForm.as_p(),
                'subType' :subItem['item_type']
                }
                listdata.append({
                "item_id":item['id'],
                'subItem_id': testcase.subItem_id,
                'item_subText': testcase.item_subText,
                'data' : data,'name' : testcase.name
                })
            if(subItem['item_type']==4):
                locateForm = LocateItemForm(subItem['locateItem_type'])
                data = {
                    'htmlCode' : subItemForm.as_p(),
                    'type' : item['item_type'],
                    'htmlLocateCode' : locateForm.as_p(),
                    'subType' :subItem['item_type']
                }
                listdata.append({
                    "item_id":item['id'],
                    'subItem_id': testcase.subItem_id,
                    'locateItem_id': testcase.locateItem_id,
                    'locateItem_subText':testcase.locateItem_subText,
                    'data' : data,'name' : testcase.name
                })
            if(subItem['item_type']==5):
                locateForm = LocateItemForm(item['locateItem_type'])
                subNameForm = ItemSubNameForm(subItem['item_subName'])
                data = {
                    'htmlCode' : subItemForm.as_p(),
                    'type' : item['item_type'],
                    'htmlLocateCode' : locateForm.as_p(),
                    'htmlNameCode' : subNameForm.as_p(),
                    'subType' :subItem['item_type']
                }
                listdata.append({
                    "item_id":item['id'],
                    'subItem_id': testcase.subItem_id,
                    'item_subText':testcase.item_subText,
                    'locateItem_id': testcase.locateItem_id,
                    'locateItem_subText':testcase.locateItem_subText,
                    'data' : data,'name' : testcase.name
                })

        if(item['item_type']==4 or item['item_type']==5):
            locateForm = LocateItemForm(item['locateItem_type'])
            data = {
                'htmlCode' : locateForm.as_p(),
                'type' : item['item_type'],
                'subName' : item['item_subName']

                }
            listdata.append({
                "item_id":item['id'],
                'locateItem_id': testcase.locateItem_id,
                'locateItem_subText': testcase.locateItem_subText,
                'item_subText' : testcase.item_subText,
                'data' : data,'name' : testcase.name
                })
        
        if(item['item_type']==6):
            subItemForm = SubItemForm(item['id'],item['item_subName'])
            locateForm = LocateItemForm(item['locateItem_type'])
            data = {
                'htmlCode' : locateForm.as_p(),
                'htmlSubCode' :subItemForm.as_p(),
                'type' : item['item_type'],
            }
            listdata.append({
                "item_id":item['id'],
                'locateItem_id': testcase.locateItem_id,
                'locateItem_subText': testcase.locateItem_subText,
                'subItem_id' : testcase.subItem_id,
                'data' : data,'name' : testcase.name
            })
        if(item['item_type'] == 7):
            superSubNameForm = SuperItemSubNameForm(item['item_subName'])
            superSubItemForm = SuperSubItemForm(item['id'],'Variable Type')
            subItem = Item.objects.filter(id=testcase.superItem_id).values('id','item_type','item_subName').first()           
            if(subItem['item_type']==2):
                subNameForm = ItemSubNameForm(subItem['item_subName'])
                data ={                   
                'htmlSuperNameCode' : superSubNameForm.as_p(),
                'htmlSuperSubCode' : superSubItemForm.as_p(),
                'htmlNameCode' : subNameForm.as_p(),
                'type' : item['item_type']
                }
                listdata.append({
                    "item_id":item['id'],
                    'item_subText': testcase.item_subText,
                    'superSubItem_type': subItem['item_type'],
                    'superSubItem_id' : testcase.superItem_id,
                    'item_superSubText': testcase.superItem_subText,
                    'data' : data,'name' : testcase.name
                })
            if(subItem['item_type']==3):
                subItemForm = SubItemForm(subItem['id'],subItem['item_subName'])
                data = {
                    'htmlSuperNameCode' : subNameForm.as_p(),
                    'htmlSuperSubCode' : superSubItemForm.as_p(),
                    'htmlSubcode' : subItemForm.as_p(),
                    'type' : item['item_type']
                }
                listdata.append({
                    "item_id":item['id'],
                    'item_superSubText': testcase.superItem_subText,
                    'superSubItem_type': subItem['item_type'],
                    'superSubItem_id' : testcase.superItem_id,
                    'subItem_id': testcase.subItem_id,
                    'data' : data,'name' : testcase.name
                })
            if(subItem['item_type']==4):
                locateForm = LocateItemForm(item['locateItem_type'])
                data = {
                    'htmlSuperNameCode' : subNameForm.as_p(),
                    'htmlSuperSubCode' : superSubItemForm.as_p(),
                    'htmlCode' : locateForm.as_p(),
                    'type' : item['item_type'],
                    'subName' : item['item_subName']

                }
                listdata.append({
                    "item_id":item['id'],
                    'locateItem_id': testcase.locateItem_id,
                    'locateItem_subText': testcase.locateItem_subText,
                    'superItem_subText' : testcase.superItem_subText,
                    'superSubItem_type': subItem['item_type'],
                    'superSubItem_id' : testcase.superItem_id,
                    'data' : data,'name' : testcase.name
                })
    return JsonResponse(listdata,safe=False)            
        
        
                
                


@csrf_protect
def runtest(request):
    size = 1
    logFile = open('mylog.txt', 'w') 
    testcase = []
    testcase.append('Run First')
    variables = []
    TestCase.objects.all().delete()
    f = createFile()
    
    
    while True:
        
        itemId = int(request.POST.get('select_item-'+str(size), 0))
        itemName = request.POST.get('item-'+str(size),"")
        itemText = request.POST.get('input_subname-'+str(size),"")
        locateId = int(request.POST.get('select_locateitem-'+str(size),0))
        locateText = request.POST.get('input_sublocate-'+str(size),"")
        subItemId = int(request.POST.get('select_subitem-'+str(size),0))
        superSubItemId = int(request.POST.get('select_supersubitem-'+str(size),0)) 
        superSubItemText = request.POST.get('input_supersubname-'+str(size),"")

        if(itemId):
            TestCase.objects.create(name=itemName,item_id = itemId, item_subText= itemText,locateItem_id=locateId,locateItem_subText=locateText,subItem_id=subItemId,superItem_id=superSubItemId, superItem_subText=superSubItemText)
            testtest(f,itemId,locateId,subItemId,superSubItemId,itemText,locateText,superSubItemText)
            size += 1
            
        else:
            break
    listvariable = []
    listvariable.append('variable:'+str(variables))
    closeFile(f)
    test = robot.run(os.getcwd()+"/polls/robot/mysuite.robot",
    stdout=logFile,
    outputdir="templates/static", exitonfailure=True)
    
    print(test)

    data = {
        'test': test
    }
     
    return JsonResponse(data)
def createFile():
    f = open(os.getcwd()+"/polls/robot/mysuite.robot",'w+')
    f.write("*** Settings ***\n\nLibrary\tSelenium2Library\nResource\tSelenium2Screenshots/keywords.robot\nLibrary\tList.py\nLibrary\tBuiltIn\nResource\tKeywords.robot\n")
    f.write("\nSuite Setup\tGo to homepage\nSuite Teardown\tClose All Browsers\n")
    f.write("\n*** Variables ***\n${HOMEPAGE}\thttp://www.google.com\n${BROWSER}\tfirefox\n${DELAY}\t0\n")
    f.write("\n*** Test Cases ***\n")
    f.write("\nMy Test Case\n")
    return f
def closeFile(f):
    f.write("\n*** Keywords ***\nGo to homepage\n\tOpen Browser\t${HOMEPAGE}\t${BROWSER}\n\tSet Selenium Speed\t${DELAY}") 
    f.close()
def tier2(request):
    if request.method == 'GET':
        did = request.GET.get('id')
        item = Item.objects.filter(id=did).values('id','locateItem_type','item_type','item_subName').first()
        
        if(item['locateItem_type'] !=0):
            locateForm = LocateItemForm(item['locateItem_type'])
            if(item['item_type']!=6):
                data = {
                'htmlCode' : locateForm.as_p(),
                'type' : item['item_type'],
                'subName' : item['item_subName']
                }
                return JsonResponse(data)
            else:
                subItemForm = SubItemForm(item['id'],item['item_subName'])
                data = {
                    'htmlCode' : locateForm.as_p(),
                    'htmlSubCode' :subItemForm.as_p(),
                    'type' : item['item_type'],
                }
                return JsonResponse(data)
        else:
            if(item['item_type'] == 3):
                subItemForm = SubItemForm(item['id'],item['item_subName'])
                data ={                   
                    'htmlCode' : subItemForm.as_p(),
                    'type' : item['item_type']
                }
                return JsonResponse(data)
            if(item['item_type'] == 2):
                subNameForm = ItemSubNameForm(item['item_subName'])
                data ={                   
                    'htmlCode' : subNameForm.as_p(),
                    'type' : item['item_type']
                }
                return JsonResponse(data)
            if(item['item_type'] == 7):
                superSubNameForm = SuperItemSubNameForm(item['item_subName'])
                superSubItemForm = SuperSubItemForm(item['id'],'Variable Type')
                data ={                   
                    'htmlNameCode' : superSubNameForm.as_p(),
                    'htmlSubCode' : superSubItemForm.as_p(),
                    'type' : item['item_type']
                }
                return JsonResponse(data)    
        return JsonResponse({'data': "" })
    return JsonResponse({'data': ""  })

def testtest(f,itemId,locateId,subItemId,superSubItemId,itemText,locateText,superSubItemText):
    
    item = Item.objects.filter(id=itemId).values('item_type').first()
    itemtype = item['item_type']
     
    if (itemtype == 1): testType1(f,itemId),
    elif (itemtype == 2): testType2(f,itemId,itemText),
    elif (itemtype == 3): testType3(f,itemId,locateId,subItemId,itemText,locateText),
    elif (itemtype == 4): testType4(f,itemId,locateId,locateText),
    elif (itemtype == 5): testType5(f,itemId,itemText,locateId,locateText),
    elif (itemtype == 6): testType6(f,itemId,locateId,subItemId,itemText,locateText),
    elif (itemtype == 7): testType7(f,itemId,locateId,subItemId,superSubItemId,itemText,locateText,superSubItemText),
    
def testType1(f,itemId):
    strTestCase = {
        12: 'Refresh Page',
        13: 'Take ScreenShot',
        18: 'Switch Back To Main',
        19: 'Switch To Next Tab',
        20: 'Switch To Previous Tab',
        21: 'Close Tab',
        22: 'Close Alert Box',
        24: 'Get Page Source',
        25: 'Get Cookies'
    }[itemId]
    
    f.write("\n\t"+strTestCase+"\n")
    return True
def testType1Sub(f,strTestCase,subItemId):
    strTestCase += {
        #SCROLL
        108:" To Top",
        109:" To Bottom",
        #SCROLL
        #PRINT IN RESULT
        111:" Current Title",
        112:" Current Url",
        114:" All Variables"
        #END PRINT IN RESULT
    }[subItemId]
    f.write("\n\t"+strTestCase+"\n")
    return True
def testType1SubSuper(f,strTestCase,subItemId,superSubItemText):
    strTestCase += {
        121: " Y-m-d",
        122: " Y-m-d H:m:s",
        123: " H-m-s",
        124: " m-d H:m:s",
    }[subItemId]
    
    return True
def testType2(f,itemId,itemText):
    strTestCase = {
        3: 'Go To Url',
        11: 'Pause',
        23: 'Execute JS'
    }[itemId]
    f.write("\n\t"+strTestCase+"\t"+itemText+"\n")
    
    return True
def testType2Sub(f,strTestCase,subItemId,itemText):
    strTestCase += {
        #ADD ASSERTION
        35: " Title Contains Value",
        36: " Url Contains Value",
        37: " Page Source Contains Value",
        38: " Cookies Contains Value",
        39: " Page Matches Screenshot",
        #END ADD ASSERTION
        #SCROLL
        104:" Down",
        105:" Up",
        106:" Left",
        107:" Right",
        110:" To Element",
        #END SCROLL
        #PRINT IN RESULT
        113:" Variable"
        #END PRINT IN RESULT
    }[subItemId]
    f.write("\n\t"+strTestCase+"\t"+itemText+"\n")
    return True
def testType2SubSuper(f,strTestCase,superSubItemId,itemText,superSubItemText):
    strTestCase += {
        115: " Set Value",
        116: " Set Password",
        117: " Random Number",
        118: " Random String",
        119: " Random Email",
        126: " Exact Value From JS"
    }[superSubItemId]
    
    return True

def testType3(f,itemId,locateId,subItemId,itemText,locateText):
    

    strTestCase = {
        5:  "Add Assertion",
        10: "Scroll",
        15: "Print In Result",
        26: "Import testcases",
    }[itemId]
    subItem = Item.objects.filter(id=subItemId).values('item_type').first()
    subItemType = subItem['item_type']
    if (subItemType == 1): testType1Sub(f,strTestCase,subItemId),           
    elif (subItemType == 2): testType2Sub(f,strTestCase,subItemId,itemText),
    elif (subItemType == 4): testType4Sub(f,strTestCase,subItemId,locateId,locateText),
    elif (subItemType == 5): testType5Sub(f,strTestCase,subItemId,locateId,locateText,itemText)        
     
    return True
def testType3SubSuper(f,strTestCase,superSubItemId,locateId,subItemId,itemText,locateText,superSubItemText):
    strTestCase += {
        120: " TimeStamp"
    }[superSubItemId]
    subItem = Item.objects.filter(id=subItemId).values('item_type').first()
    {
        1: testType1SubSuper(f,strTestCase,subItemId,superSubItemText)           
            
    }[subItem['item_type']]
    return True
def testType4(f,itemId,locateId,locateText):
    
    strTestCase = {
        1:"Click GUI Element",
        8:"Hover GUI Element",
        9:"Right Click",
        14:"Snipping Tool",
        17:"Switch To Iframe"
    }[itemId]
    strLocator= testLocate(locateId)
    
    if(locateId == 3):
        f.write("\n\t"+strTestCase+"\t"+strLocator+"\t//*[text()='"+locateText+"']\t2\n")
    else: f.write("\n\t"+strTestCase+"\t"+strLocator+"\t"+locateText+"\t2\n")
    
    return True
def testType4Sub(f,strTestCase,subItemId,locateId,locateText):
    strTestCase += {
        #ADD ASSERTION
        27:  " Element Is Present",
        28:   " Element Is Not Present"
        #END ADD ASSERTION
    }[subItemId]
    strLocator = testLocate(locateId)
    if(locateId == 3):
        f.write("\n\t"+strTestCase+"\t"+strLocator+"\t//*[text()="+locateText+"]\t2\n")
    else: 
        f.write("\n\t"+strTestCase+"\t"+strLocator+"\t"+locateText+"\t2\n")
    
    return True

def testType4SubSuper(f,strTestCase,superSubItemId,locateId,locateText,superSubItemText):
    strTestCase += {
        125: " Exact Value From Element"
    }[superSubItemId]
    strTestCase += testLocate(locateId)

    return True
def testType5(f,itemId,itemText,locateId,locateText):

    strTestCase = {
        2: "Insert Text",
        4: "Select Option",
        6: "Upload File"
    }[itemId]
    strLocator = testLocate(locateId)
    f.write("\n\t"+strTestCase+"\t"+strLocator+"\t"+locateText+"\t"+itemText+"\t2\n")
    
    return True
def testType5Sub(f,strTestCase,subItemId,locateId,locateText,itemText):
    strTestCase += {
        #ADD ASSERTION
        29: " Element Matches Value",
        30: " Element Does Not Match Value",
        32: " Element Does Not Contain Value",
        31: " Element Contains Value",
        33: " Count Child Elements",
        34: " Variable Assertion",
        40: " Element Matches Screenshot"
        #END ADD ASSERTION
    }[subItemId]
    strLocator = testLocate(locateId)
     
    if(locateId == 3):
        f.write("\n\t"+strTestCase+"\t"+strLocator+"\t//*[text()="+locateText+"]\t"+itemText+"\t2\n")
    else: 
        f.write("\n\t"+strTestCase+"\t"+strLocator+"\t"+locateText+"\t"+itemText+"\t2\n")
    return True

def testType6(f,itemId,locateId,subItemId,itemText,locateText):
    strTestCase = {
        7: "Press Keyword"
    }[itemId]
    strLocator = testLocate(locateId)
    strKey = testPressKey(subItemId)
    f.write("\n\t"+strTestCase+"\t"+strLocator+"\t"+locateText+"\t"+strKey+"\t2\n")
    return True
def testType7(f,itemId,locateId,subItemId,superSubItemId,itemText,locateText,superSubItemText):
    strTestCase = {
        16:"Set Variable"
    }[itemId]
    subItem = Item.objects.filter(id=superSubItemId).values('item_type').first()
    {
        
        2: testType2SubSuper(f,strTestCase,superSubItemId,itemText,superSubItemText),
        3: testType3SubSuper(f,strTestCase,superSubItemId,locateId,subItemId,itemText,locateText,superSubItemText),
        4: testType4SubSuper(f,strTestCase,superSubItemId,locateId,locateText,superSubItemText)
               
    }[subItem['item_type']]
    return True
def testLocate(locateId):
    
    strTest = {
        1: "name",
        2: "id",
        3: "xpath",
        4: "class",
        5: "xpath",
        6: "css",
        7: "link",
        8: "partial link",
        9: " By Variable Contains Value",
        10: " By Variable Matchs Value",
        11: " By Variable Does Not Contains Value",
        12: " By Variable Does Not Match Value"
    }[locateId]
    return strTest

def testPressKey(subItemId):
    strKey = {
        #PRESS KEY
        41: "\\\\43",
        42: "ALT",
        43: "ARROW_DOWN",
        44: "ARROW_UP",
        45: "ARROW_LEFT",
        46: "ARROW_RIGHT",
        47: "\\\\8",
        48: "BACK_SPACE",
        49: "\\\\24",
        50: "CLEAR",
        51: "COMMAND",
        52: "CONTROL",
        53: "\\\\46",
        54: "\\\\127",
        55: "\\\\47",
        56: "DOWN",
        57: "\\\\25",
        58: "\\\\13",
        59: "\\\\61",
        60: "\\\\27",
        61: "F1",
        62: "F2",
        63: "F3",
        64: "F4",
        65: "F5",
        66: "F6",
        67: "F7",
        68: "F8",
        69: "F9",
        70: "F10",
        71: "F11",
        72: "F12",
        73: "HELP",
        74: "INSERT",
        75: "LEFT",
        76: "LEFT_ALT",
        77: "LEFT_CONTROL",
        78: "\\\\14",
        79: "META",
        80: "\\\\42",
        81: "\\\\0",
        82: "\\\\48",
        83: "\\\\49",
        84: "\\\\50",
        85: "\\\\51",
        86: "\\\\52",
        87: "\\\\53",
        88: "\\\\54",
        89: "\\\\55",
        90: "\\\\56",
        91: "\\\\57",
        92: "PAGE_DOWN",
        93: "PAGE_UP",
        94: "PAUSE",
        95: "RETURN",
        96: "RIGHT",
        97: "\\\\59",
        98: "\\\\15",
        99: "\\\\32",
        100: "\\\\47",
        101: "\\\\45",
        102: "\\\\9",
        103: "UP"
    }[subItemId]
    return strKey