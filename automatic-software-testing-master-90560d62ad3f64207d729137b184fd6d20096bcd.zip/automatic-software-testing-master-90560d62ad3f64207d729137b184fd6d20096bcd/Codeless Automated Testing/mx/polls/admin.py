from django.contrib import admin

# Register your models here.
from .models import Item, LocateItem,TestCase

class ItemAdmin(admin.ModelAdmin):
    list_display = ('id', 'item_text', 'item_type', 'parent_id', 'locateItem_type')
    list_display_links = ('id', 'item_text', 'item_type')
    search_fields = ('item_text', 'item_type', 'parent_id', 'locateItem_type')
    list_filter = ('item_type','parent_id')
    list_per_page = 25

class LocateItemAdmin(admin.ModelAdmin):
    list_display = ('id', 'locate_text', 'locate_type')
    list_display_links = ('id', 'locate_text')
    search_fields = ('locate_text', 'locate_type')
    list_per_page = 25
admin.site.register(Item,ItemAdmin)
admin.site.register(LocateItem,LocateItemAdmin)
admin.site.register(TestCase)